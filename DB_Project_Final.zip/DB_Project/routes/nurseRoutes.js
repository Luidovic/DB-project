const express = require("express");
const { result } = require("lodash");
const mysql = require("mysql2");
const connection = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "root",
	database: "medicalclinic",
	// rowsAsArray: true,
});

//new o=instance of the router its like a mini app it must be used inside it.
const router = express.Router();

router.get("/nurse", (req, res) => {
	const username = req.query.q;
	const sql = `SELECT FIRSTNAME,LASTNAME, EMAIL,PHONENUMBER FROM NURSE WHERE username = '${username}' `;

	connection.query(sql, (error, results) => {
		if (error) throw error;
		const [rows, fields] = results;
		console.log(rows.FIRSTNAME);
		res.render("nurse", {
			name: rows.FIRSTNAME + " " + rows.LASTNAME,
			email: rows.EMAIL,
			phone: rows.PHONENUMBER,
		});
	});
});

router.post("/data", (req, res) => {
	connection.query(
		`SELECT * FROM NURSE N, CHECKS C WHERE N.nurseId = C.nurseID`,
		(error, results) => {
			if (error) throw error;
			const [rows, fields] = results;
			console.log(rows);
			res.send(rows);
		}
	);
});

module.exports = router;
