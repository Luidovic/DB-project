const express = require("express");
const mysql = require("mysql2");
const connection = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "root",
	database: "medicalclinic",
	rowsAsArray: true,
});
//new o=instance of the router its like a mini app it must be used inside it.
const rout = express.Router();
rout.get("/Doctor", (req, res) => {
	const username = req.query.q;
	console.log(username);
	const sql = `SELECT FIRSTNAME,LASTNAME, EMAIL,PHONENUMBER FROM DOCTOR WHERE username = '${username}' `;
	connection.query(sql, (error, results) => {
		if (error) throw error;
		const [rows, fields] = results;
		res.render("Doctor", {
			name: rows[0] + " " + rows[1],
			email: rows[2],
			phone: rows[3],
		});
	});
});
module.exports = rout;
