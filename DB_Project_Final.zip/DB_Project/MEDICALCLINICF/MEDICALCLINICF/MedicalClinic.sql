CREATE DATABASE  IF NOT EXISTS `medicalclinic` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medicalclinic`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medicalclinic
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `appointmentID` varchar(10) NOT NULL,
  `appointmenttype` varchar(255) DEFAULT NULL,
  `examinationroom` varchar(255) DEFAULT NULL,
  `appointmentdate` date NOT NULL,
  PRIMARY KEY (`appointmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES ('001','General examination','400','2021-10-02'),('002','General examination','401','2021-10-02'),('003','Emergency','402','2021-10-02'),('004','Emergency','402','2022-11-25'),('005','Check up','403','2022-11-25'),('006','Check up','403','2020-06-25'),('007','Check up','403','2022-12-18');
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `belongsto`
--

DROP TABLE IF EXISTS `belongsto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `belongsto` (
  `doctorID` int NOT NULL,
  `ssn` varchar(12) NOT NULL,
  `visittime` datetime NOT NULL,
  PRIMARY KEY (`doctorID`,`ssn`,`visittime`),
  KEY `ssn` (`ssn`),
  KEY `visittime` (`visittime`),
  CONSTRAINT `belongsto_ibfk_1` FOREIGN KEY (`doctorID`) REFERENCES `doctor` (`doctorID`),
  CONSTRAINT `belongsto_ibfk_3` FOREIGN KEY (`visittime`) REFERENCES `ehr` (`visittime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `belongsto`
--

LOCK TABLES `belongsto` WRITE;
/*!40000 ALTER TABLE `belongsto` DISABLE KEYS */;
INSERT INTO `belongsto` VALUES (1,'001265849751','2020-12-12 08:10:00'),(2,'007855815952','2021-07-25 11:10:00'),(3,'007855815951','2022-08-18 09:00:00'),(1,'001265849751','2022-11-10 10:00:00');
/*!40000 ALTER TABLE `belongsto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `appointmentID` varchar(10) NOT NULL,
  `doctorID` int NOT NULL,
  `receptionistID` int NOT NULL,
  `ssn` varchar(12) NOT NULL,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  PRIMARY KEY (`appointmentID`,`doctorID`,`receptionistID`,`ssn`),
  KEY `doctorID` (`doctorID`),
  KEY `receptionistID` (`receptionistID`),
  KEY `ssn` (`ssn`),
  CONSTRAINT `books_ibfk_1` FOREIGN KEY (`appointmentID`) REFERENCES `appointments` (`appointmentID`),
  CONSTRAINT `books_ibfk_2` FOREIGN KEY (`doctorID`) REFERENCES `doctor` (`doctorID`),
  CONSTRAINT `books_ibfk_3` FOREIGN KEY (`receptionistID`) REFERENCES `receptionist` (`receptionistID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES ('001',1,1,'001265849751','09:00:00','09:40:00'),('002',2,1,'005648972310','09:00:00','09:50:00'),('003',3,2,'007855815952','11:45:00','12:23:00');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checks`
--

DROP TABLE IF EXISTS `checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checks` (
  `roomnumber` varchar(3) NOT NULL,
  `nurseID` int NOT NULL,
  PRIMARY KEY (`roomnumber`,`nurseID`),
  KEY `nurseID` (`nurseID`),
  CONSTRAINT `checks_ibfk_2` FOREIGN KEY (`nurseID`) REFERENCES `nurse` (`nurseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checks`
--

LOCK TABLES `checks` WRITE;
/*!40000 ALTER TABLE `checks` DISABLE KEYS */;
INSERT INTO `checks` VALUES ('101',1),('201',1),('301',1),('302',1),('202',2),('203',2),('303',2),('400',2);
/*!40000 ALTER TABLE `checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cleans`
--

DROP TABLE IF EXISTS `cleans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cleans` (
  `roomnumber` varchar(3) NOT NULL,
  `staffID` int NOT NULL,
  PRIMARY KEY (`roomnumber`,`staffID`),
  KEY `staffID` (`staffID`),
  CONSTRAINT `cleans_ibfk_2` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleans`
--

LOCK TABLES `cleans` WRITE;
/*!40000 ALTER TABLE `cleans` DISABLE KEYS */;
INSERT INTO `cleans` VALUES ('100',1),('103',1),('200',1),('202',1),('203',1),('300',1),('303',1),('400',1),('101',2),('102',2),('201',2),('301',2),('302',2),('401',2),('402',2),('403',2);
/*!40000 ALTER TABLE `cleans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor` (
  `doctorID` int NOT NULL,
  `ssn` varchar(12) DEFAULT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `dateofbirth` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` char(1) NOT NULL,
  `phonenumber` decimal(11,0) NOT NULL,
  `scheduletime` varchar(20) DEFAULT NULL,
  `empstartdate` date NOT NULL,
  `empenddate` date DEFAULT NULL,
  PRIMARY KEY (`doctorID`),
  CONSTRAINT `doctor_chk_1` CHECK ((`gender` in (_utf8mb4'M',_utf8mb4'F')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (1,'000091023461','Alice','White','Alice.White','AW001','Beirut','1990-12-03','alice.white@hotmail.com','F',96171258861,'08:00:00 17:00:00','2020-02-03',NULL),(2,'056489123468','John','Black','John.Black','JB002','Byblos','1992-10-07','john.black@hotmail.com','M',96171335544,'08:00:00 15:00:00','2021-08-04',NULL),(3,'000676124358','Bob','Yellow','Bob.Yellow','BY003','Kaslik','1965-08-25','bob.yellow@hotmail.com','M',96171654654,'08:00:00 19:30:00','2003-05-25','2013-06-28');
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ehr`
--

DROP TABLE IF EXISTS `ehr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ehr` (
  `visittime` datetime NOT NULL,
  `allergies` varchar(255) DEFAULT NULL,
  `bloodtype` varchar(3) DEFAULT NULL,
  `height` decimal(5,2) DEFAULT NULL,
  `medicationtaken` varchar(255) DEFAULT NULL,
  `surgicalhistory` varchar(255) DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `doctorassessment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`visittime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ehr`
--

LOCK TABLES `ehr` WRITE;
/*!40000 ALTER TABLE `ehr` DISABLE KEYS */;
INSERT INTO `ehr` VALUES ('2020-12-12 08:10:00','G6PD','A+',160.00,'Aspirin','Open-Heart Surgery',59.00,'Stable condition'),('2021-07-25 11:10:00','Asthma','AB',184.00,'Lasix','Kidney Stones Surgery',85.00,'Stable condition'),('2022-08-18 09:00:00','Hives','O+',150.00,'Depakine','Nevous System Surgery',51.00,'Needs check up'),('2022-11-10 10:00:00','G6PD','A+',175.00,'Aspirin','Open-Heart Surgery',69.00,'Needs check up');
/*!40000 ALTER TABLE `ehr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labs`
--

DROP TABLE IF EXISTS `labs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `labs` (
  `labID` varchar(10) NOT NULL,
  `labtype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`labID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labs`
--

LOCK TABLES `labs` WRITE;
/*!40000 ALTER TABLE `labs` DISABLE KEYS */;
INSERT INTO `labs` VALUES ('001','Blood testing LAB'),('002','Blood testing LAB'),('003','Blood testing LAB'),('004','Blood testing LAB'),('005','Blood testing LAB'),('102','Urine testing LAB'),('103','Urine testing LAB'),('201','Cholesterol testing LAB'),('202','Cholesterol testing LAB'),('203','Cholesterol testing LAB'),('301','Microbiology LAB'),('302','Microbiology LAB'),('303','Microbiology LAB');
/*!40000 ALTER TABLE `labs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nurse`
--

DROP TABLE IF EXISTS `nurse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nurse` (
  `nurseID` int NOT NULL,
  `ssn` varchar(12) DEFAULT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `dateofbirth` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` char(1) NOT NULL,
  `phonenumber` decimal(11,0) NOT NULL,
  `scheduletime` varchar(20) DEFAULT NULL,
  `empstartdate` date NOT NULL,
  `empenddate` date DEFAULT NULL,
  PRIMARY KEY (`nurseID`),
  CONSTRAINT `nurse_chk_1` CHECK ((`gender` in (_utf8mb4'M',_utf8mb4'F')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nurse`
--

LOCK TABLES `nurse` WRITE;
/*!40000 ALTER TABLE `nurse` DISABLE KEYS */;
INSERT INTO `nurse` VALUES (1,'001567819437','Harley','Angel','Harley.Angel','HA001','Beirut','1980-04-05','harley.angel@hotmail.com','F',96171567887,'07:00:00 22:00:00','2002-05-21',NULL),(2,'001265849750','Steve','Hill','Steve.Hill','SH002','Byblos','1985-06-07','steve.hill@hotmail.com','M',96176197854,'22:00:00 07:00:00','2002-06-17',NULL);
/*!40000 ALTER TABLE `nurse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operates`
--

DROP TABLE IF EXISTS `operates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operates` (
  `doctorID` int NOT NULL,
  `operationID` varchar(10) NOT NULL,
  `ssn` varchar(12) NOT NULL,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  PRIMARY KEY (`doctorID`,`ssn`,`operationID`),
  KEY `operationID` (`operationID`),
  KEY `ssn` (`ssn`),
  CONSTRAINT `operates_ibfk_1` FOREIGN KEY (`doctorID`) REFERENCES `doctor` (`doctorID`),
  CONSTRAINT `operates_ibfk_2` FOREIGN KEY (`operationID`) REFERENCES `operations` (`operationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operates`
--

LOCK TABLES `operates` WRITE;
/*!40000 ALTER TABLE `operates` DISABLE KEYS */;
INSERT INTO `operates` VALUES (1,'003','007855815952','11:20:00','12:52:00'),(2,'001','001265849751','08:00:00','11:20:00'),(3,'002','007855815951','10:00:00','10:40:00');
/*!40000 ALTER TABLE `operates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operations`
--

DROP TABLE IF EXISTS `operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operations` (
  `operationID` varchar(10) NOT NULL,
  `operationtype` varchar(255) DEFAULT NULL,
  `operationroom` varchar(255) DEFAULT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  PRIMARY KEY (`operationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operations`
--

LOCK TABLES `operations` WRITE;
/*!40000 ALTER TABLE `operations` DISABLE KEYS */;
INSERT INTO `operations` VALUES ('001','Open-Heart surgery','101',50000.00,'2022-12-01','2022-12-01'),('002','Cataract surgery','102',4000.00,'2022-12-01','2022-12-01'),('003','Kidney Stones surgery','103',3000.00,'2022-12-05','2022-12-05');
/*!40000 ALTER TABLE `operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `ssn` varchar(12) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `dateofbirth` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` char(1) NOT NULL,
  `phonenumber` decimal(11,0) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ssn`),
  CONSTRAINT `patient_chk_1` CHECK ((`gender` in (_utf8mb4'M',_utf8mb4'F')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES ('001265849751','Kaiser','Mclure','Kaiser.Mclure','KM001','Beirut','1985-06-07','kaiser.mclure@hotmail.com','M',96176197854,'He has cardiovascular problems. He takes aspirin (100mg) twice per day.'),('005648972310','Jeanette','Light','Jeanette.Light','JL004','Jbeil','2020-01-01','mary.ship@hotmail.com','F',96170648972,'She has H1N1 problems. She takes oseltamivir once per day.'),('007855815951','Henry','Gold','Henry.Gold','HG002','Zalka','2002-08-13','henry.gold@hotmail.com','M',96176684851,'He has vision problems. He takes eyedrops three times per day.'),('007855815952','Mary','Ship','Mary.Ship','MS003','Rabieh','2002-08-13','mary.ship@hotmail.com','F',96170648972,'She has intestine problems. She takes normoix once per day.');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prescribes`
--

DROP TABLE IF EXISTS `prescribes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prescribes` (
  `doctorID` int NOT NULL,
  `ssn` varchar(12) NOT NULL,
  `treatmentID` varchar(10) NOT NULL,
  PRIMARY KEY (`doctorID`,`ssn`,`treatmentID`),
  KEY `ssn` (`ssn`),
  KEY `treatmentID` (`treatmentID`),
  CONSTRAINT `prescribes_ibfk_1` FOREIGN KEY (`doctorID`) REFERENCES `doctor` (`doctorID`),
  CONSTRAINT `prescribes_ibfk_3` FOREIGN KEY (`treatmentID`) REFERENCES `treatments` (`treatmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescribes`
--

LOCK TABLES `prescribes` WRITE;
/*!40000 ALTER TABLE `prescribes` DISABLE KEYS */;
INSERT INTO `prescribes` VALUES (2,'001265849751','001'),(3,'005648972310','002'),(1,'007855815952','003');
/*!40000 ALTER TABLE `prescribes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provides`
--

DROP TABLE IF EXISTS `provides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provides` (
  `labID` varchar(10) NOT NULL,
  `ssn` varchar(12) NOT NULL,
  `testresultID` varchar(10) NOT NULL,
  PRIMARY KEY (`labID`,`ssn`,`testresultID`),
  KEY `ssn` (`ssn`),
  KEY `testresultID` (`testresultID`),
  CONSTRAINT `provides_ibfk_1` FOREIGN KEY (`labID`) REFERENCES `labs` (`labID`),
  CONSTRAINT `provides_ibfk_3` FOREIGN KEY (`testresultID`) REFERENCES `testresults` (`testresultID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provides`
--

LOCK TABLES `provides` WRITE;
/*!40000 ALTER TABLE `provides` DISABLE KEYS */;
INSERT INTO `provides` VALUES ('302','007855815951','004'),('102','005648972310','007');
/*!40000 ALTER TABLE `provides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receptionist`
--

DROP TABLE IF EXISTS `receptionist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receptionist` (
  `receptionistID` int NOT NULL,
  `extension` decimal(4,0) DEFAULT NULL,
  `ssn` varchar(12) DEFAULT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `dateofbirth` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` char(1) NOT NULL,
  `phonenumber` decimal(11,0) NOT NULL,
  `scheduletime` varchar(20) DEFAULT NULL,
  `empstartdate` date NOT NULL,
  `empenddate` date DEFAULT '0000-00-00',
  PRIMARY KEY (`receptionistID`),
  CONSTRAINT `receptionist_chk_1` CHECK ((`gender` in (_utf8mb4'M',_utf8mb4'F')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receptionist`
--

LOCK TABLES `receptionist` WRITE;
/*!40000 ALTER TABLE `receptionist` DISABLE KEYS */;
INSERT INTO `receptionist` VALUES (1,2163,'005648456780','Sophie','Dark','Sophie.Dark','SD001','Beirut','1960-12-24','sophie.dark@hotmail.com','F',96170112255,'07:00:00 16:00:00','2000-01-25',NULL),(2,1233,'001649785780','Nadine','Pink','Nadine.Pink','NP002','Byblos','1965-06-04','nadine.pink@hotmail.com','F',96171266544,'07:00:00 16:00:00','2005-08-05',NULL);
/*!40000 ALTER TABLE `receptionist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserves`
--

DROP TABLE IF EXISTS `reserves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reserves` (
  `receptionistID` int NOT NULL,
  `roomnumber` varchar(3) NOT NULL,
  `ssn` varchar(12) NOT NULL,
  PRIMARY KEY (`receptionistID`,`roomnumber`,`ssn`),
  KEY `roomnumber` (`roomnumber`),
  KEY `ssn` (`ssn`),
  CONSTRAINT `reserves_ibfk_1` FOREIGN KEY (`receptionistID`) REFERENCES `receptionist` (`receptionistID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserves`
--

LOCK TABLES `reserves` WRITE;
/*!40000 ALTER TABLE `reserves` DISABLE KEYS */;
INSERT INTO `reserves` VALUES (1,'400','001265849751'),(2,'401','007855815951'),(2,'402','007855815952'),(1,'403','005648972310');
/*!40000 ALTER TABLE `reserves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `roomnumber` varchar(3) NOT NULL,
  `roomfloor` int DEFAULT NULL,
  `roomtype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`roomnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES ('100',1,'Surgery room'),('101',1,'Surgery room'),('102',1,'Surgery room'),('103',1,'Surgery room'),('200',2,'Intensive care unit'),('201',1,'Intensive care unit'),('202',2,'Intensive care unit'),('203',2,'Intensive care unit'),('300',3,'Recovery room'),('301',3,'Recovery room'),('302',3,'Recovery room'),('303',3,'Recovery room'),('400',4,'Examination room'),('401',4,'Examination room'),('402',4,'Examination room'),('403',4,'Examination room');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `staffID` int NOT NULL,
  `ssn` varchar(12) DEFAULT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `dateofbirth` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` char(1) NOT NULL,
  `phonenumber` decimal(11,0) NOT NULL,
  `scheduletime` varchar(20) DEFAULT NULL,
  `empstartdate` date NOT NULL,
  `empenddate` date DEFAULT '0000-00-00',
  PRIMARY KEY (`staffID`),
  CONSTRAINT `staff_chk_1` CHECK ((`gender` in (_utf8mb4'M',_utf8mb4'F')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'001897564751','Rami','Gate','Rami.Gate','RG001','Beirut','1986-07-05','rami.gate@hotmail.com','M',96171257799,'06:00:00 20:30:00','2000-12-01',NULL),(2,'002365987411','Jean','Boyd','Jean.Boyd','JB002','Byblos','1989-02-03','jean.boyd@hotmail.com','M',96171784512,'06:00:00 20:30:00','2000-12-02',NULL);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testresults`
--

DROP TABLE IF EXISTS `testresults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `testresults` (
  `testresultID` varchar(10) NOT NULL,
  `testtype` varchar(255) DEFAULT NULL,
  `resultdate` date NOT NULL,
  `bill` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`testresultID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testresults`
--

LOCK TABLES `testresults` WRITE;
/*!40000 ALTER TABLE `testresults` DISABLE KEYS */;
INSERT INTO `testresults` VALUES ('001','Echography','2020-05-22',60.00),('002','Radiology','2020-06-02',57.00),('003','Radiology','2021-01-02',57.00),('004','Biopsy','2022-08-07',255.00),('005','Brain scan','2022-04-07',115.00),('006','Electrocardiogram','2022-12-07',100.00),('007','Urine sample','2022-08-17',40.00),('008','Skin sample test','2022-11-17',60.00),('009','Thyroid test','2022-12-27',200.00);
/*!40000 ALTER TABLE `testresults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatments`
--

DROP TABLE IF EXISTS `treatments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatments` (
  `treatmentID` varchar(10) NOT NULL,
  `treatmenttype` varchar(255) DEFAULT NULL,
  `medicinetype` varchar(255) DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `startdate` date NOT NULL,
  `enddate` date DEFAULT NULL,
  PRIMARY KEY (`treatmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatments`
--

LOCK TABLES `treatments` WRITE;
/*!40000 ALTER TABLE `treatments` DISABLE KEYS */;
INSERT INTO `treatments` VALUES ('001','Valve Replacement','ApoCapto',10,'2022-12-02',NULL),('002','Neurological Seizures','Depakine',70,'2022-10-12',NULL),('003','Kidney Stones Removal','Lasix',20,'2022-08-01',NULL);
/*!40000 ALTER TABLE `treatments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-19  1:33:06
