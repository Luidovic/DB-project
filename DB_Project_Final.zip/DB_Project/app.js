const express = require("express");
const mysql = require("mysql2");
const nurseRoutse = require("./routes/nurseRoutes");
const app = express();
const doctorRoute = require("./routes/Doctor");
//connection with databse
const connection = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "root",
	database: "medicalclinic",
	rowsAsArray: true,
});

//Check Connection with database
connection.connect(function (error) {
	if (error) throw error;
	console.log("Connected to the MySQL server.");
});

// register view engine to make HTML non static
app.set("view engine", "ejs");

//Which port is it listening to
app.listen(3000);

//middleware and static files
app.use(express.static("public"));
app.use(express.urlencoded({ extended: false }));

//Homepage
app.get("/", (req, res) => {
	res.render("home");
});

//Login page
app.get("/login", (req, res) => {
	res.render("login");
	console.log(req.form);
});

//About page
app.get("/About", (req, res) => {
	res.render("About");
});

// Login form request which sends to the corresponding page dependant on the role (Which represents the table in mysql) that he chose
app.post("/form", (req, res) => {
	const name = req.body.username;
	const pass = req.body.password;
	const role = req.body.role;
	const sql = `SELECT username, pass FROM ${role} WHERE username =? AND pass =?`;
	const values = [name, pass];
	connection.query(sql, values, (err, results) => {
		if (err) throw err;
		else if (results.length > 0) {
			if (role == "Nurse") {
				res.redirect(`/nurse?q=${name}`);
			} else if (role == "Patient") {
				res.redirect("/Patient");
			} else if (role == "Doctor") {
				res.redirect(`/Doctor?q=${name}`);
			} else if (role == "Receptionist") {
				res.redirect("/Receptionist");
			} else if (role == "Staff") {
				res.send("login successful to Staff");
			}
		} else {
			res.send("Invalid username or password");
		}
	});
	connection.end();
});

app.use(nurseRoutse);
app.use(doctorRoute);
