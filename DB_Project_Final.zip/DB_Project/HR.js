const express = require("express");
const mysql = require("mysql2");
const app = express();
const connection = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "root",
	database: "medicalclinic",
	rowsAsArray: true,
});

app.use(express.static("public"));
app.use(express.urlencoded({ extended: false }));

app.set("view engine", "ejs");
app.listen(5000);

app.get("/", (req, res) => {
	res.render("HR");
});

app.post("/for", (req, res) => {
	//inputs from the HR site to add them to dtabaase.
	const firstName = req.body.firstName;
	const lastName = req.body.lastName;
	const email = req.body.email;
	const ssn = req.body.ssn;
	const phone = req.body.phone;
	const date_of_birth = req.body.date_of_birth;
	const address = req.body.address;
	const male = req.body.male;
	const female = req.body.female;
	const table = req.body.table;
	const start_date = req.body.start_date;
	const end_date = req.body.end_date;
	const work_days = req.body.work_days;
	const work_start = req.body.work_start;
	const work_end = req.body.work_end;
	const password = req.body.password;
	const username = req.body.username;
	let gender = "";
	if (male != null) {
		gender = "M";
	} else {
		gender = "F";
	}
	if (male != null || female != null) {
		throw error;
	}
	//define the primary key from tables to get it into the following querri

	let pk = "id";
	if (`${table}` == "Doctor") {
		pk = "doctorID";
	} else if (`${table}` == "Nurse") {
		pk = "nurseID";
	} else if (`${table}` == "Staff") {
		pk = "staffID";
	} else if (`${table}` == "Receptionist") {
		pk = "receptionistID";
	}

	// async function getMaxValue() {
	// 	// Select the maximum value from the table
	// 	const [rows, fields] = connection.query(
	// 		`SELECT MAX(${pk}) AS max_value FROM ${table}`
	// 	);

	// 	// Get the maximum value from the result
	// 	const maxValue = rows[0].max_value;
	// 	connection.end();

	// 	return maxValue;
	// }
	// Select the maximum value of id from the table using the function defined previously
	//getMaxValue().then((value) => {
	const maxValue = 20 + 1;

	// log to console to check inly
	//console.log(`The maximum value is: ${maxValue}`);
	//});
	const sql = `INSERT INTO ${table} VALUES(10,'${ssn}','${firstName}','${lastName}',
	'${username}','${password}','${address}','${date_of_birth}','${email}','${gender}',${phone},'${work_start}+" "+ ${work_end}','${start_date}','${end_date}')`;
	connection.query(sql, (err, result) => {
		console.log(result);
		res.render("HR");
	});
	connection.end;
});
